read -p 'Enter the Number : ' number

reversed=$(echo "$number" | rev)

echo "Reversed Number : $reversed"
