#!/bin/bash

gcc rb.c rb_data.c rb_test.c && time ./a.out
